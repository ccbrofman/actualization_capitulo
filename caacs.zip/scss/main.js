// const footer= document.getElementById ('Pie')
// console.log (footer.innerHTML)
